export interface Blog {
    id: number,
    title: string,
    image: string,
    author_image: string,
    category:string,
    author: string,
    publish_date: string,
    slug: string,
    description: string,
    content: string
}
