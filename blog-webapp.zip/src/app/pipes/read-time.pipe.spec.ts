import { ReadTimePipe } from './read-time.pipe';

describe('ReadTimePipe', () => {
  it('create an instance', () => {
    const pipe = new ReadTimePipe();
    expect(pipe).toBeTruthy();
  });
});
